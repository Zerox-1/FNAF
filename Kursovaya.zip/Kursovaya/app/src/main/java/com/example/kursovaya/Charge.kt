package com.example.kursovaya

fun Charge(){
    if(Battarey<=100){
        Battarey+=1}
}