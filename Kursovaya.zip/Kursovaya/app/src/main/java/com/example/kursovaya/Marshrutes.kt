package com.example.kursovaya

object Marshroutes {
    val route1 = "Главное меню"
    val route2 = "Игра"
    val route3 = "Таблица"
    val route4="Продолжить Игра"
    val route5="Регистрация"
    val route6="Регистрация1"
    val route7="Получить сохранение"
    val route8="Сделать сохранение"
}